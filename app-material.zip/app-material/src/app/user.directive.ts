import { Directive } from '@angular/core';

@Directive({
  selector: '[appUser]'
})
export class UserDirective {

  constructor() { }

}

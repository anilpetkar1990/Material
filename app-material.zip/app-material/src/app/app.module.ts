import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';


import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { MaterialModule } from './material/material.module';
import { RequestComponent } from './request/request.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { UserDirective } from './user.directive';


@NgModule({
  declarations: [
    AppComponent,
    RequestComponent,
    UserDirective
    
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,   
    AppRoutingModule,
    MaterialModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

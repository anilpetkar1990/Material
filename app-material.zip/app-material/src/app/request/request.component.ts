import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.css']
})
export class RequestComponent implements OnInit {

  email = new FormControl('', [Validators.required, Validators.email]);
  selected = 'angular';
  mindate=new Date();
  maxdate = new Date(2022,3,22);

  datefilter=(date:any)=>{
    const day=date.getDay();
    return day!= 0 && day!=6
  }

  constructor() { }

  ngOnInit(): void {
  }

  getErrorMessage() {
    if (this.email.hasError('required')) {
      return 'You must enter a value';
    }

    return this.email.hasError('email') ? 'Not a valid email' : '';
  }

}
